<?php

namespace Yunpian\Sdk\Api;

/**
 *
 * @author dzh
 * @since 1.0
 */
class VoidApi extends YunpianApi {
    
    const NAME = "void";

}